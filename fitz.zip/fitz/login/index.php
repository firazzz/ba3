<?php
include ('block/block.php');
header("Location: login.php");


?>
